package ITCompany;
public class HRDept extends SuperDept {
    public String deptName()
    {
        return "Hr Department";
    }
    public String getTodaysWork()
    {
        return "Fill today’s worksheet and mark your attendance";   
    }
    public String getWorkDeadline()
    {
        return "Complete by EOD";
    }
    public String doActivity()
    {
        return "team Lunch";
    }   
}
