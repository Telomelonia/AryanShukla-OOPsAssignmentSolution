package ITCompany;
public class TechDept extends SuperDept {
    public String deptName()
    {
        return "Tech Department";
    }
    public String getTodaysWork()
    {
        return "Complete coding of module 1";   
    }
    public String getWorkDeadline()
    {
        return "Complete by EOD";
    }
    public String getTechStackInformation()
    {
        return "core Java";
    }   
}
