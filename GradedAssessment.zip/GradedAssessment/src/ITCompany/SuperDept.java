package ITCompany;

public class SuperDept{
    String deptName()
    {
        return "Super Department";
    }
    String getTodaysWork()
    {
        return "No work as of now";   
    }
    String getWorkDeadline()
    {
        return "Nil";
    }
    public String isTodayAHoliday()
    {
        return "Today is not a holiday";
    }
}
