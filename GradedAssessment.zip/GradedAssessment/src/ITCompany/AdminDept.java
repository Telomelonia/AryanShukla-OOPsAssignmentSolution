package ITCompany;
public class AdminDept extends SuperDept{
    public String deptName()
    {
        return "Admin Department";
    }
    public String getTodaysWork()
    {
        return "Complete your documents Submission";   
    }
    public String getWorkDeadline()
    {
        return "Complete by EOD";
    }
}