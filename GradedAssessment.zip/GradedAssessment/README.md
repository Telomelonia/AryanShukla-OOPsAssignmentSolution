Driver.java is solution and is in src
ITcompany package contains all the related classes.


